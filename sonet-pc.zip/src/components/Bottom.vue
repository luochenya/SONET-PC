<template>
  <div class="Bottom">
    © 2013-2020 DolfanxtFFFT
  </div>
</template>

<script>
export default {
  name: "Bottom"
}
</script>

<style lang="scss" scoped>
.Bottom {
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 100px;
  background: #F6F7F8;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 14px;
  font-weight: 500;
  color: #585858;
  line-height: 20px;
}
</style>
